const express = require('express');
const app = express();
const port = 8070; // 사용할 포트번호

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});